---
title: 下载并安装Emeditor文本编辑器
abbrlink: 22559
date: 2022-11-29 11:54:22
categories:
tags:
permalink:
---

# 下载并安装Emeditor文本编辑器

1. 下载地址：https://www.emeditor.com/#download

![下载Emeditor安装包](下载并安装Emeditor文本编辑器/image-9461129112919.png)

2. 下载完成后双击Emeditor安装包，然后点击下一步

![双击安装包开始安装Emeditor](下载并安装Emeditor文本编辑器/image-5421129113040.png)

3. 选择安装类型，不能选择，只能保持默认，点击下一步

![安装类型只能保持默认](下载并安装Emeditor文本编辑器/image-4981129113114.png)

4. 接受许可，点击下一步

![接受安装许可协议](下载并安装Emeditor文本编辑器/image-9081129113235.png)

5. 选择安装类型：自定义安装

![安装类型选择自定义](下载并安装Emeditor文本编辑器/image-3881129113347.png)

6. 点击程序菜单快捷方式和文件关联，点击下一步

![自定义安装](下载并安装Emeditor文本编辑器/image-7431129113525.png)

7. 点击安装，等待安装完成

![安装](下载并安装Emeditor文本编辑器/image-2081129113833.png)

8. 点击完成，启动Emeditor文本编辑器

![Emeditor安装完成](下载并安装Emeditor文本编辑器/image-1451129113914.png)

9. 点击"使用EmEditor Professional"，输入注册码

![点击专业版进行激活](下载并安装Emeditor文本编辑器/image-8091129114016.png)

![输入注册码](下载并安装Emeditor文本编辑器/image-8451129114551.png)

![激活成功](下载并安装Emeditor文本编辑器/image-1669694165860.png)
